#!/usr/bin/env python3
import requests
import sys
import os
import json
import cgi
import cgitb
import sys
from googletrans import Translator
from PIL import Image
from io import BytesIO
import matplotlib.pyplot as plt
import pyimgur
import json
def process(data):
    return json.loads(data)['param']
def main(data):
    client_id = '84d0e8e76ea3fe4'
    api_key = client_secret = 'ba2d7cbb7f3e6645636e96aac9b95174ca02840b'
    CLIENT_ID = client_id
    output = 'output'
    PATH = None
    for poss in ['.jpg', '.png', '.jpeg', '.txt']:
        if os.path.isfile('image'+poss):
            PATH = 'image'+poss
            break
    if PATH:
        """
        jsontext = {output: PATH.read()}
        print(json.dumps(jsontext, sort_keys=False,indent=4, separators=(',', ': ')))
        return
        """
        im = pyimgur.Imgur(CLIENT_ID)
        uploaded_image = im.upload_image(PATH, title="Uploaded with PyImgur")
        image_url = uploaded_image.link
    else:
        image_url = "http://braziliangringo.com/wp-content/uploads/2015/05/caminho.png"
    subscription_key = "b93fdefa52ba49d48a0efb7b89efd4e3"
    vision_base_url = "https://westcentralus.api.cognitive.microsoft.com/vision/v1.0/"

    headers  = {'Ocp-Apim-Subscription-Key': subscription_key }
    params   = {'language' : 'unk'} #{'visualFeatures': 'Categories,Description,Color', 'language' : 'unk', 'detectOrientation' : 'true', 'handwriting' : True}
    data     = {'url': image_url}

    ocr_url = vision_base_url + "ocr"
    text_url = vision_base_url + "RecognizeText"
    response = requests.post(ocr_url, headers=headers, params=params, json=data)
    response.raise_for_status()
    analysis = response.json()
    line_infos = [region["lines"] for region in analysis["regions"]]
    word_infos = []
    for line in line_infos:
        for word_metadata in line:
            for word_info in word_metadata["words"]:
                word_infos.append(word_info)
#word_infos
    hah = ""
    for word in word_infos:
        text = word["text"]
        if text == "11m":
            text = "I'm"
        hah += text.strip() + ' '
        if len(hah) > 5 and hah[-2] == '.' and hah[-3].lower() in "qwertyuiopasdfghjklzxcvbnm":
            hah += '\n'
    translator = Translator()
    finaltext = translator.translate(hah, dest='en').text
    jsontext = {output: finaltext.strip()}
    return json.dumps(jsontext, sort_keys=False,indent=4, separators=(',', ': '))
def fakemain(nothing):
    jsontext = {'text' : 'hey hello ehasdf'}
    val = json.dumps(jsontext, sort_keys=False,indent=4, separators=(',', ': '))
    return val
if __name__ == "__main__":
    jsontext = {'text' : 'hey hello ehasdf'}
    f = open("HELLO2.txt", "w")
    """
    form = cgi.FieldStorage()
    form_ok = 0
    if form.has_key('param'):
        form_ok = 1
    f.write(form_ok)
    f.close()
    if form_ok == 1:
        form_ok = '1 ' + str(form['param'].value)
    #val = json.dumps(jsontext, sort_keys=False,indent=4, separators=(',', ': '))
    """
    print("Content-Type: application/json")
    print()
    print(json.dumps({'text' : 'a;sldfja;lsdk;alsj'}, sort_keys=False,indent=4,separators=(',', ': ')))
#main(sys.argv[1])
