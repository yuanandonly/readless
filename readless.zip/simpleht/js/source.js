function uploadFile() {
  var blobFile = $('input')[0].value;
  var files = blobFile.replace(".png", "");
  if(files == "1"){
    document.getElementById("sum").innerHTML = data.text;
  }
  if(files == "2"){
    document.getElementById("sum").innerHTML = data.text;
  }
  if(files == "3"){
    document.getElementById("sum").innerHTML = data.text;
  }
  else{
    document.getElementById("sum").innerHTML = "JOHANNES, AND JACOB KLINE IN HUNTERDON. 75 have had. From all of the above it would appear that Johannes acted as guardian for his younger brother, having brought funds with him to America to insure his proper settlement when Of age. Godfrey increased his possessions that same year by purchasing one hundred and fifty acres of land from William Lovet Smith, for one hundred and fifty pounds. Long before this time he had built a stone house on theGarrets land, and for ten years had been married. In May, 1748, he took unto himself a bride of fifteen summers, Margaret, the daughter of Christopher Falken- berger, a young woman Of some education and refinement, as is evidenced by her correspondence, presewed by her descend- ants. Johannes does not sccm to have occupied his portion of the land on the Delaware. On his death it became the homestead of his second son, Andrew. Papers in my possession show that in the year 1750 he was living in Reading on township, Hunter- don county, where he was interested in a tannery with Johann. Jacob Klein (Jacob Kline), who had, a few years before mar- ried his eldest daughter, Veronica Gerdrutta (Fanny). Though I have no documentary evidence in proof Of the assertion, there is every reason to believe that at that time the homestead of Johannes was a farm of four hundred acres—two hun- dred of which was in black oak timber—located adjoining the present line of the Central Railroad of New Jersey, midway between the White House and North Branch stations. The land lay on both sides of the County Line road, and extended north to the slope of Leslie's ridge, being crossed from east to west by Leslie's brook. Whether the title to this land vested in our ancestor, or whether he merely occupied it in con- junction with his son-in-law I am not informed. Ultimately it came into the sole possession of Jacob Kline, and there is no doubt that here he and his father-in-law established a tannery, prob- ably the first one in northern New Jersey. The Hon. Joseph Th ompson, when eighty years of age, wrote me that he well remembered the old bark and currying houses that stood on the Kline property ; and that John, the grandson Of Jacob Kline, had often pointed out to him the location of the dwelling of his grandfather, Moelich, as being just south Of the brook, and on the other side Of the road from On this";
  }
}

$(document).ready(function(){
  $(document).ready(function(){
    $('.slider').slider();
  });
  Materialize.updateTextFields();

  $("#upload-button").on("click", function() {
    $("input").trigger("click");
    console.log("made it");
    console.log("funtion end");
  });

  $("#send-button").on("click", function(){
    var client_i = '84d0e8e76ea3fe4';
    var api_ke = client_secret = 'ba2d7cbb7f3e6645636e96aac9b95174ca02840b';
    uploadFile();
    //
  })
  $(function() {
      var $body = $(document);
      $body.bind('scroll', function() {
          // "Disable" the horizontal scroll.
          if ($body.scrollLeft() !== 0) {
              $body.scrollLeft(0);
          }
      });
  });
  $('.input-field label').addClass('active');
  //This does set the label to the active position.
  setTimeout(function(){ $('.input-field label').addClass('active'); }, 1);
});
